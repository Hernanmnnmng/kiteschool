<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <title>Pakketten | Windkracht-12</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
</head>
<body>

  <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <main class="container">
    <h1>Lespakketten</h1>

    

    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="pakket">
    <h2><?php echo e($package->name); ?></h2>
    <p>€<?php echo e($package->price); ?> – <?php echo e($package->duration_minutes / 60); ?> uur</p>
    <p><?php echo e($package->description); ?></p>
    <form method="GET" action="/reserve">
      <input type="hidden" name="package" value="<?php echo e($package->id); ?>">
      <button type="submit" class="btn">Reserveer</button>
    </form>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </main>

</body>
</html><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/pakketten.blade.php ENDPATH**/ ?>