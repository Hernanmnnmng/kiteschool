<!-- Start Navigation -->
<nav class="navbar navbar-default bootsnav navbar-fixed dark no-background">

<div class="container">

    <!-- Start Header Navigation -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
            <i class="fa fa-bars"></i>
        </button>
        <a class="navbar-brand" href="#index">Kitesurfschool Windkracht-12</a>
    </div><!--/.navbar-header-->
    <!-- End Header Navigation -->

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu">
        <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
        <li class=" smooth-menu active"></li>
            <li class=" smooth-menu"><a href="#education">education</a></li>
            <li class="smooth-menu"><a href="#skills">skills</a></li>
            <li class="smooth-menu"><a href="#experience">experience</a></li>
            <li class="smooth-menu"><a href="#profiles">profile</a></li>
            <li class="smooth-menu"><a href="#portfolio">portfolio</a></li>
            <?php if(auth()->guard()->check()): ?>
            <li class="smooth-menu">
                <a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
            </li>
        <?php else: ?>
            <li class="smooth-menu">
                <a href="<?php echo e(route('login')); ?>">Log in</a>
            </li>
            <?php if(Route::has('register')): ?>
                <li class="smooth-menu">
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
        </ul><!--/.nav -->
    </div><!-- /.navbar-collapse -->
</div><!--/.container-->
</nav><!--/nav-->
<!-- End Navigation --><?php /**PATH /Users/hernanmartinomolina/Desktop/Versbellign qwjehfrqliwrfghh wceiu/versnelling2025/resources/views/partials/navbar.blade.php ENDPATH**/ ?>