<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Mijn Lessen</title>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
</head>
<body>
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="container">
        <h1>Mijn Geplande Lessen</h1>

        <?php if($reservations->isEmpty()): ?>
            <p>Je hebt momenteel geen ingeplande lessen.</p>
        <?php else: ?>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="pakket">
                    <h2><?php echo e($reservation->lessonPackage->name); ?></h2>
                    <p><strong>Klant:</strong> <?php echo e($reservation->user->name); ?></p>
                    <p><strong>Datum:</strong> <?php echo e($reservation->date); ?></p>
                    <p><strong>Tijd:</strong> <?php echo e($reservation->time); ?></p>
                    <p><strong>Status:</strong> <?php echo e($reservation->status); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </main>
</body>
</html><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/instructor/lessons.blade.php ENDPATH**/ ?>