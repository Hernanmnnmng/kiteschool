<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>