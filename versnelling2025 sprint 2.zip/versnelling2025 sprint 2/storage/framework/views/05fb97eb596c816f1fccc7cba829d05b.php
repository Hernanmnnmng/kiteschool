<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Reservering Goedgekeurd</title>
</head>
<body>
    <h2>Hallo <?php echo e($reservation->user->name); ?>,</h2>

    <p>Goed nieuws! Je reservering voor <strong><?php echo e($reservation->lessonPackage->name); ?></strong> is goedgekeurd.</p>

    <p><strong>Datum:</strong> <?php echo e($reservation->date); ?></p>
    <p><strong>Tijd:</strong> <?php echo e($reservation->time); ?></p>

    <p>We kijken ernaar uit je te zien bij Windkracht-12! 🌬️</p>

    <p>Met vriendelijke groet,<br>Team Windkracht-12</p>
</body>
</html><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/emails/reservation-approved.blade.php ENDPATH**/ ?>