<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .crippy-wrapper {
            max-width: 600px;
            margin: 40px auto;
            background-color: #f3f7ff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            font-family: 'Segoe UI', sans-serif;
            color: #222;
        }

        .crippy-wrapper h1 {
            color: #0055aa;
            margin-bottom: 20px;
        }

        .crippy-form-group {
            margin-bottom: 20px;
        }

        .crippy-form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        .crippy-form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccddee;
            border-radius: 5px;
        }

        .crippy-button {
            background-color: #007bff;
            color: white;
            padding: 10px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }

        .crippy-button:hover {
            background-color: #0056b3;
        }

        .crippy-alert {
            background-color: #d4edda;
            color: #155724;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>

    <div class="crippy-wrapper">
        <h1>Jouw Beschikbaarheid</h1>

        <?php if($availabilities->isEmpty()): ?>
            <p>Je hebt nog geen beschikbaarheid toegevoegd.</p>
        <?php else: ?>
            <table class="w-full border">
                <thead>
                    <tr>
                        <th class="border px-4 py-2">Datum</th>
                        <th class="border px-4 py-2">Van</th>
                        <th class="border px-4 py-2">Tot</th>
                        <th class="border px-4 py-2">Actie</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $availabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border px-4 py-2"><?php echo e($availability->date); ?></td>
                            <td class="border px-4 py-2"><?php echo e($availability->start_time); ?></td>
                            <td class="border px-4 py-2"><?php echo e($availability->end_time); ?></td>
                            <td class="border px-4 py-2 text-center">
                                <form action="<?php echo e(route('availability.delete', $availability->id)); ?>" method="POST" onsubmit="return confirm('Weet je zeker dat je deze beschikbaarheid wilt verwijderen?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="crippy-button" style="background-color: #dc3545;">Verwijder</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/instructor/availability-overview.blade.php ENDPATH**/ ?>