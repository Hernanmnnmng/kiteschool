<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Mijn Lessen</title>
    <link rel="stylesheet" href="{{ asset('frontend/css/style.css') }}">
</head>
<body>
    @include('partials.navbar')

    <main class="container">
        <h1>Mijn Geplande Lessen</h1>

        @if ($reservations->isEmpty())
            <p>Je hebt momenteel geen ingeplande lessen.</p>
        @else
            @foreach ($reservations as $reservation)
                <div class="pakket">
                    <h2>{{ $reservation->lessonPackage->name }}</h2>
                    <p><strong>Klant:</strong> {{ $reservation->user->name }}</p>
                    <p><strong>Datum:</strong> {{ $reservation->date }}</p>
                    <p><strong>Tijd:</strong> {{ $reservation->time }}</p>
                    <p><strong>Status:</strong> {{ $reservation->status }}</p>
                </div>
            @endforeach
        @endif
    </main>
</body>
</html>