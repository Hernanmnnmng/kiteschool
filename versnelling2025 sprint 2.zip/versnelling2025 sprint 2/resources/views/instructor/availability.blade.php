<x-app-layout>
    <style>
        .crippy-wrapper {
            max-width: 600px;
            margin: 40px auto;
            background-color: #f3f7ff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            font-family: 'Segoe UI', sans-serif;
            color: #222;
        }

        .crippy-wrapper h1 {
            color: #0055aa;
            margin-bottom: 20px;
        }

        .crippy-form-group {
            margin-bottom: 20px;
        }

        .crippy-form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        .crippy-form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccddee;
            border-radius: 5px;
        }

        .crippy-button {
            background-color: #007bff;
            color: white;
            padding: 10px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }

        .crippy-button:hover {
            background-color: #0056b3;
        }

        .crippy-alert {
            background-color: #d4edda;
            color: #155724;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>

    <div class="crippy-wrapper">
        <h1>Beschikbaarheid Toevoegen</h1>

        @if (session('success'))
            <div class="crippy-alert">
                {{ session('success') }}
            </div>
        @endif

        <form action="{{ route('availability.store') }}" method="POST">
            @csrf

            <div class="crippy-form-group">
                <label for="date">Datum:</label>
                <input type="date" name="date" id="date" required min="{{ now()->format('Y-m-d') }}" max="{{ now()->addDays(45)->format('Y-m-d') }}">
            </div>

            <div class="crippy-form-group">
                <label for="start_time">Starttijd:</label>
                <select name="start_time" id="start_time" required>
                    <option value="09:00">09:00 – 12:00</option>
                    <option value="13:00">13:00 – 16:00</option>
                    <option value="12:00">Zaterdag 12:00 – 17:00</option>
                </select>
            </div>

            <div class="crippy-form-group">
                <label for="end_time">Eindtijd:</label>
                <select name="end_time" id="end_time" required>
                    <option value="12:00">12:00</option>
                    <option value="16:00">16:00</option>
                    <option value="17:00">17:00</option>
                </select>
            </div>

            <button type="submit" class="crippy-button">Toevoegen</button>
        </form>
    </div>
</x-app-layout>