<x-app-layout>
    <style>
        .crippy-wrapper {
            max-width: 600px;
            margin: 40px auto;
            background-color: #f3f7ff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            font-family: 'Segoe UI', sans-serif;
            color: #222;
        }

        .crippy-wrapper h1 {
            color: #0055aa;
            margin-bottom: 20px;
        }

        .crippy-form-group {
            margin-bottom: 20px;
        }

        .crippy-form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        .crippy-form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccddee;
            border-radius: 5px;
        }

        .crippy-button {
            background-color: #007bff;
            color: white;
            padding: 10px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }

        .crippy-button:hover {
            background-color: #0056b3;
        }

        .crippy-alert {
            background-color: #d4edda;
            color: #155724;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>

    <div class="crippy-wrapper">
        <h1>Jouw Beschikbaarheid</h1>

        @if ($availabilities->isEmpty())
            <p>Je hebt nog geen beschikbaarheid toegevoegd.</p>
        @else
            <table class="w-full border">
                <thead>
                    <tr>
                        <th class="border px-4 py-2">Datum</th>
                        <th class="border px-4 py-2">Van</th>
                        <th class="border px-4 py-2">Tot</th>
                        <th class="border px-4 py-2">Actie</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($availabilities as $availability)
                        <tr>
                            <td class="border px-4 py-2">{{ $availability->date }}</td>
                            <td class="border px-4 py-2">{{ $availability->start_time }}</td>
                            <td class="border px-4 py-2">{{ $availability->end_time }}</td>
                            <td class="border px-4 py-2 text-center">
                                <form action="{{ route('availability.delete', $availability->id) }}" method="POST" onsubmit="return confirm('Weet je zeker dat je deze beschikbaarheid wilt verwijderen?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="crippy-button" style="background-color: #dc3545;">Verwijder</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
</x-app-layout>