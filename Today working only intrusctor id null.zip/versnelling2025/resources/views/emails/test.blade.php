<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h2>Hello from Windkracht12</h2>
    <p>This is a test email to confirm Mailtrap is working!</p>
</body>
</html>