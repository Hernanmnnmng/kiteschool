<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Bevestig je betaling</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 40px;
            color: #333;
        }
        .container {
            max-width: 600px;
            background-color: #fff;
            border-radius: 8px;
            padding: 30px;
            margin: auto;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        .header {
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
        }
        .header h1 {
            color: #0077b6;
        }
        p {
            line-height: 1.6;
            font-size: 15px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            margin-top: 10px;
        }
        .btn-success {
            background-color: #28a745;
        }
        .btn-fail {
            background-color: #dc3545;
            margin-left: 10px;
        }
        .footer {
            margin-top: 30px;
            font-size: 13px;
            color: #999;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Kitesurfschool Windkracht-12</h1>
        </div>

        <p>Beste {{ $reservation->user->name }},</p>

        <p>Bedankt voor je reservering bij Kitesurfschool Windkracht-12!</p>

        <p>Klik op een van de onderstaande knoppen om je betaling te simuleren:</p>

        <a href="{{ route('reservations.fakepay', [$reservation->id, 'success']) }}" class="btn btn-success">Succesfull Pay</a>
        <a href="{{ route('reservations.fakepay', [$reservation->id, 'fail']) }}" class="btn btn-fail">Unsuccesfull Pay</a>

        <p class="footer">Let op: deze betaling is alleen ter demonstratie. Deze mail is automatisch gegenereerd.</p>
    </div>
</body>
</html>