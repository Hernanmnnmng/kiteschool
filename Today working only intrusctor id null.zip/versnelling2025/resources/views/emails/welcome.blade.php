<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to Kitesurfschool Windkracht-12</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f8fb;
            color: #333;
            padding: 40px;
        }
        .container {
            max-width: 600px;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            padding: 30px;
            margin: auto;
        }
        h1 {
            color: #0077b6;
        }
        p {
            font-size: 16px;
            line-height: 1.5;
        }
        .footer {
            margin-top: 30px;
            font-size: 14px;
            color: #999;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Kitesurfschool Windkracht-12! 🏄‍♂️</h1>
        <p>Hi there,</p>
        <p>Thank you for registering at our kitesurfing school! We’re thrilled to have you on board.</p>
        <p>Get ready for an exciting experience filled with wind, waves, and adventure.</p>
        <p>If you have any questions or want to book your first lesson, just reply to this email or log in to your dashboard.</p>
        <p>We’ll see you on the beach soon! 🌊</p>
        <div class="footer">
            &copy; {{ date('Y') }} Kitesurfschool Windkracht-12. All rights reserved.
        </div>
    </div>
</body>
</html>
