<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Over Ons | Windkracht-12</title>
  <link rel="stylesheet" href="{{ asset('frontend/css/style.css') }}">
  <style>
    .crippywindsurf-section {
      max-width: 800px;
      margin: 40px auto;
      background: #f0f8ff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
      font-family: 'Segoe UI', sans-serif;
      color: #333;
    }
    .crippywindsurf-section h1 {
      color: #0077cc;
      margin-bottom: 20px;
      text-align: center;
    }
    .crippywindsurf-section p {
      margin-bottom: 16px;
      line-height: 1.6;
    }
    .crippywindsurf-section img {
      width: 100%;
      border-radius: 8px;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  @include('partials.navbar')

  <main class="crippywindsurf-section">
    <img src="{{ asset('frontend/images/kitesurf-hero.jpg') }}" alt="Over Windkracht-12">
    <h1>Over Windkracht-12</h1>
    <p>Welkom bij Windkracht-12! Wij zijn gepassioneerd over kitesurfen en bieden professionele lessen aan voor zowel beginners als gevorderden.</p>
    <p>Onze instructeurs zijn gecertificeerd en hebben jarenlange ervaring op het water. Of je nu je eerste stap wilt zetten of je skills wilt verbeteren, bij ons ben je in goede handen.</p>
    <p>We geloven in veiligheid, plezier en persoonlijke aandacht. Onze lessen vinden plaats op een prachtige locatie met de beste omstandigheden voor kitesurfen.</p>
    <p>Kom langs en ervaar de kracht van de wind bij Windkracht-12!</p>
  </main>

</body>
</html>