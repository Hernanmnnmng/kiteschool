<x-app-layout>
    @include('partials.navbar')

    <div class="max-w-4xl mx-auto p-6 bg-white rounded shadow">
        <h1 class="text-2xl font-bold mb-6">Mijn Geplande Lessen</h1>

        @if ($reservations->isEmpty())
            <p class="text-gray-600">Je hebt momenteel geen ingeplande lessen.</p>
        @else
            <ul class="space-y-4">
                @foreach ($reservations as $reservation)
                    <li class="border p-4 rounded bg-gray-50">
                        <h2 class="text-lg font-semibold">{{ $reservation->lessonPackage->name }}</h2>
                        <p><strong>Klant:</strong> {{ $reservation->user->name }}</p>
                        <p><strong>Datum:</strong> {{ $reservation->date }}</p>
                        <p><strong>Tijd:</strong> {{ $reservation->time }}</p>
                        <p><strong>Status:</strong> {{ ucfirst($reservation->status) }}</p>
                    </li>
                @endforeach
            </ul>
        @endif
    </div>
</x-app-layout>