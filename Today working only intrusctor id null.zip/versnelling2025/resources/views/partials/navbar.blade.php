<!-- Public Navbar -->
<nav class="public-navbar hernannav-navbar">
    <div class="hernannav-container">
        <a href="{{ url('/') }}" class="hernannav-logo">Kitesurfschool <span>Windkracht-12</span></a>

        <!-- Hamburger -->
        <div class="hernannav-hamburger" onclick="document.getElementById('hernannav-links').classList.toggle('hernannav-show')">
            ☰
        </div>

        <!-- Links -->
        <ul class="hernannav-links" id="hernannav-links">
            <!-- Guest/User Dropdown -->
            @guest
                        <li><a href="{{ route('pakketten') }}">Pakketten</a></li>
                        <li><a href="{{ route('reservations') }}">Reserveren</a></li>
                        <li><a href="{{ route('about') }}">About Us</a></li>
                        <li><a href="{{ route('contact') }}">Contact</a></li>
            @endguest

           @auth
    @if (auth()->user()->isUser())
        <li><a href="{{ route('pakketten') }}">Pakketten</a></li>
        <li><a href="{{ route('reservations') }}">Reserveren</a></li>
        <li><a href="{{ route('mijn-reservaties') }}">Mijn Reservaties</a></li>
        <li><a href="{{ route('faq') }}">FAQ</a></li>
        <li><a href="{{ route('contact') }}">Contact</a></li>
        <li><a href="{{ route('about') }}">About Us</a></li>
    @endif
@endauth

            <!-- Worker Dropdown -->
            @auth
                @if (auth()->user()->isWorker())
                    <li class="dropdown">
                        <a href="#">Instructeur ▾</a>
                        <ul class="dropdown-menu">
                            <li><a href="{{ route('availability.form') }}">Beschikbaarheid Toevoegen</a></li>
                            <li><a href="{{ route('availability.view') }}">Beschikbaarheid Overzicht</a></li>
                            <li><a href="{{ route('instructor.lessons') }}">Mijn Lessen</a></li>
                        </ul>
                    </li>
                @endif
            @endauth

            <!-- Admin/Worker Reserveringsbeheer -->
            @auth
                @if (auth()->user()->isAdmin() || auth()->user()->isWorker())
                    <li><a href="{{ route('beheer') }}">Reserveringsbeheer</a></li>
                @endif
            @endauth

            <!-- Auth Links -->
            @guest
                <li><a href="{{ route('login') }}">Log in</a></li>
                @if (Route::has('register'))
                    <li><a href="{{ route('register') }}">Register</a></li>
                @endif
            @else
                <li><a href="{{ url('/dashboard') }}">Profiel</a></li>
            @endguest
        </ul>
    </div>
</nav>

<style>
    .hernannav-navbar {
    background-color: white;
    border-bottom: 1px solid #eee;
    position: sticky;
    top: 0;
    z-index: 1050;
    width: 100%;
    padding: 0.75rem 1.5rem;
    font-family: 'Poppins', sans-serif;
}

.hernannav-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
}

.hernannav-logo {
    font-weight: 600;
    font-size: 1.2rem;
    color: #333;
    text-decoration: none;
}

.hernannav-logo span {
    color: #7e22ce; /* Purple */
}

.hernannav-hamburger {
    font-size: 1.5rem;
    cursor: pointer;
    display: none;
}

.hernannav-links {
    list-style: none;
    display: flex;
    gap: 1.25rem;
}

.hernannav-links li a {
    text-decoration: none;
    color: #333;
    font-weight: 500;
}

.hernannav-links li a:hover {
    color: #7e22ce;
}

.dropdown {
    position: relative;
}

.dropdown-menu {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    background-color: white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    padding: 0.5rem 0;
    border-radius: 4px;
    min-width: 160px;
    z-index: 1000;
}

.dropdown-menu li {
    list-style: none;
}

.dropdown-menu li a {
    display: block;
    padding: 8px 16px;
    color: #333;
    text-decoration: none;
    white-space: nowrap;
}

.dropdown-menu li a:hover {
    background-color: #f0f0f0;
    color: #7e22ce;
}

.dropdown:hover .dropdown-menu {
    display: block;
}

/* Mobile Styles */
@media (max-width: 768px) {
    .hernannav-hamburger {
        display: block;
    }

    .hernannav-links {
        display: none;
        flex-direction: column;
        margin-top: 1rem;
        gap: 0.75rem;
        position: relative;
    }

    .hernannav-links.hernannav-show {
        display: flex;
    }
}
</style>