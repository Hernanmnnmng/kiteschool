<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InstructorAvailability extends Model
{
    use HasFactory;

protected $table = 'instructor_availabilities';

    protected $fillable = [
        'instructor_id',
        'date',
        'start_time',
        'end_time',
    ];

    protected $casts = [
    'start_time' => 'datetime:H:i',
    'end_time' => 'datetime:H:i',
];

    public function instructor()
    {
        return $this->belongsTo(User::class, 'instructor_id');
    }
    
}