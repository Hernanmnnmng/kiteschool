<?php

namespace App\Http\Controllers;

use App\Models\Reservation;
use Illuminate\Http\Request;

class ReservationController extends Controller
{
    public function fakePayment($id, $status)
    {
        $reservation = Reservation::findOrFail($id);

        if ($status === 'success') {
            $reservation->status = 'betaald';
            $reservation->save();

            return redirect('/')->with('success', 'Betaling geslaagd! We wachten op bevestiging van de eigenaar.');
        }

        return redirect('/')->with('error', 'Betaling mislukt. Probeer het later opnieuw.');
    }
}