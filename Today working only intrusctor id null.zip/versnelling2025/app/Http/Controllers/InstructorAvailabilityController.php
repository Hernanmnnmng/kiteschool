<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\InstructorAvailability;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class InstructorAvailabilityController extends Controller
{
    public function create()
    {
        if (optional(Auth::user())->role !== 'worker') {
            abort(403);
        }

        return view('instructor.availability');
    }

    public function store(Request $request)
    {
        if (optional(Auth::user())->role !== 'worker') {
            abort(403);
        }

        $request->validate([
            'date' => 'required|date',
            'start_time' => 'required',
            'end_time' => 'required|after:start_time',
        ]);

        InstructorAvailability::create([
            'instructor_id' => Auth::id(),
            'date' => $request->date,
            'start_time' => $request->start_time,
            'end_time' => $request->end_time,
        ]);

        return redirect()->route('availability.form')->with('success', 'Beschikbaarheid toegevoegd!');
    }
    public function destroy($id)
{
    $availability = \App\Models\InstructorAvailability::where('id', $id)
        ->where('instructor_id', Auth::id())
        ->firstOrFail();

    $availability->delete();

    return redirect()->route('availability.view')->with('success', 'Beschikbaarheid verwijderd.');
}
}