<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Beheer Reservaties | Windkracht-12</title>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
</head>
<body>

<?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="container">
    <h1>Beheer Reservaties</h1>

    <?php if($reservations->isEmpty()): ?>
        <p>Er zijn momenteel geen openstaande reservaties.</p>
    <?php else: ?>
        <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(in_array($reservation->status, ['pending', 'betaald'])): ?>
                <div class="pakket">
                    <h2><?php echo e($reservation->lessonPackage->name); ?></h2>
                    <p><?php echo e($reservation->lessonPackage->description); ?></p>
                    <p>Geboekt door: <?php echo e($reservation->user->name); ?> (<?php echo e($reservation->user->email); ?>)</p>
                    <p>Datum: <?php echo e($reservation->date); ?> – Tijd: <?php echo e($reservation->time); ?></p>
                    <p>Status: <strong><?php echo e(ucfirst($reservation->status)); ?></strong></p>

                    <?php if($reservation->status === 'betaald'): ?>
                        <!-- PATCH: Accepteer reservatie -->
                        <form method="POST" action="<?php echo e(route('reservations.approve', $reservation->id)); ?>" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn">Accepteer</button>
                        </form>
                    <?php endif; ?>

                    <!-- PATCH: Weiger reservatie (altijd tonen) -->
                    <form method="POST" action="<?php echo e(route('reservations.reject', $reservation->id)); ?>" style="display:inline;" onsubmit="return confirm('Weet je zeker dat je deze reservatie wilt weigeren?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="btn">Weiger</button>
                    </form>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</main>

</body>
</html><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/beheer.blade.php ENDPATH**/ ?>