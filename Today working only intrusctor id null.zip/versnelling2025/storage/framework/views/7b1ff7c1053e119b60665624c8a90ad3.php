<?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .crippy-wrapper {
            max-width: 600px;
            margin: 40px auto;
            background-color: #f3f7ff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            font-family: 'Segoe UI', sans-serif;
            color: #222;
        }

        .crippy-wrapper h1 {
            color: #0055aa;
            margin-bottom: 20px;
        }

        .crippy-form-group {
            margin-bottom: 20px;
        }

        .crippy-form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        .crippy-form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccddee;
            border-radius: 5px;
        }

        .crippy-button {
            background-color: #007bff;
            color: white;
            padding: 10px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }

        .crippy-button:hover {
            background-color: #0056b3;
        }

        .crippy-alert {
            background-color: #d4edda;
            color: #155724;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>

    <div class="crippy-wrapper">
        <h1>Beschikbaarheid Toevoegen</h1>

        <?php if(session('success')): ?>
            <div class="crippy-alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('availability.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="crippy-form-group">
                <label for="date">Datum:</label>
                <input type="date" name="date" id="date" required min="<?php echo e(now()->format('Y-m-d')); ?>" max="<?php echo e(now()->addDays(45)->format('Y-m-d')); ?>">
            </div>

            <div class="crippy-form-group">
                <label for="start_time">Starttijd:</label>
                <select name="start_time" id="start_time" required>
                    <option value="09:00">09:00 – 12:00</option>
                    <option value="13:00">13:00 – 16:00</option>
                    <option value="12:00">Zaterdag 12:00 – 17:00</option>
                </select>
            </div>

            <div class="crippy-form-group">
                <label for="end_time">Eindtijd:</label>
                <select name="end_time" id="end_time" required>
                    <option value="12:00">12:00</option>
                    <option value="16:00">16:00</option>
                    <option value="17:00">17:00</option>
                </select>
            </div>

            <button type="submit" class="crippy-button">Toevoegen</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/instructor/availability.blade.php ENDPATH**/ ?>