<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Contact</title>
    <script src="https://cdn.emailjs.com/dist/email.min.js"></script>
    <script>
        (function(){
            emailjs.init("YOUR_USER_ID"); // Replace with your EmailJS user ID
        })();
    </script>
</head>
<body class="bg-gray-100 font-sans">
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="max-w-xl mx-auto my-10 bg-white p-8 rounded-lg shadow-md">
        <h1 class="text-2xl font-bold text-center text-blue-600 mb-6">Neem contact op</h1>

        <form id="contact-form" class="space-y-4">
            <div>
                <label class="block font-semibold mb-1">Naam:</label>
                <input type="text" name="user_name" required class="w-full border border-gray-300 rounded px-4 py-2">
            </div>

            <div>
                <label class="block font-semibold mb-1">Email:</label>
                <input type="email" name="user_email" required class="w-full border border-gray-300 rounded px-4 py-2">
            </div>

            <div>
                <label class="block font-semibold mb-1">Bericht:</label>
                <textarea name="message" rows="4" required class="w-full border border-gray-300 rounded px-4 py-2"></textarea>
            </div>

            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Verzenden</button>
        </form>

        <p id="success-msg" class="bg-green-100 text-green-700 p-3 mt-4 rounded hidden">Je bericht is verzonden!</p>

        <div class="mt-10 space-y-2 text-gray-700">
            <p><strong>Email:</strong> <a href="mailto:342353@student.mboutrecht.nl" class="text-blue-600 hover:underline">342353@student.mboutrecht.nl</a></p>
            <p><strong>Telefoon:</strong> <a href="tel:+31000000000" class="text-blue-600 hover:underline">+31 00 000 0000</a></p>
            <p><strong>Locatie:</strong> <a href="https://goo.gl/maps/GeYZhBJMR5YVZDKB7" target="_blank" class="text-blue-600 hover:underline">Bekijk op Google Maps</a></p>
        </div>

        <div class="mt-6 rounded overflow-hidden">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2442.3880538981914!2d5.121420115796344!3d52.09073777973942!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c66f3c77925807%3A0x7d324928d1c7b6c5!2sMBO%20Utrecht!5e0!3m2!1snl!2snl!4v1625657482375!5m2!1snl!2snl"
                width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy">
            </iframe>
        </div>
    </div>

    <script>
        document.getElementById('contact-form').addEventListener('submit', function(event) {
            event.preventDefault();
            emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', this)
                .then(function() {
                    document.getElementById('success-msg').classList.remove('hidden');
                }, function(error) {
                    alert('Fout bij verzenden: ' + JSON.stringify(error));
                });
        });
    </script>
</body>
</html><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/contact.blade.php ENDPATH**/ ?>