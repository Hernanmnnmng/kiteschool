<h1 style="font-size: 3.5rem; font-weight: 900; line-height: 1.2;">
    <span style="color: white;">Windkracht</span>
    <span style="color: #a8e0ff;">12</span>
</h1><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/components/application-logo.blade.php ENDPATH**/ ?>