<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <title>Reserveren | Windkracht-12</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
</head>
<body>

  <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <main class="container">
    <?php if(session('error')): ?>
      <div class="alert error" style="background-color: #fdd; color: #a00; padding: 10px; border: 1px solid #a00; border-radius: 4px; margin-bottom: 20px;">
        <?php echo e(session('error')); ?>

      </div>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
      <h1>Reserveren</h1>
      <p>Je moet ingelogd zijn om een reservering te maken.</p>
      <a href="<?php echo e(route('login')); ?>" class="btn">Log in</a>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
      <?php if($selectedPackage): ?>
        <div class="reservation-form">
          <img src="<?php echo e(asset('frontend/images/kitesurf-hero.jpg')); ?>" alt="Kitesurfen" style="width: 100%; border-radius: 8px; margin-bottom: 20px;">
          <h1>Reserveer: <?php echo e($selectedPackage->name); ?></h1>
          <p><?php echo e($selectedPackage->description); ?></p>

          <form action="<?php echo e(url('/reserve')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="lesson_package_id" value="<?php echo e($selectedPackage->id); ?>">

            <div>
              <label for="date">Datum:</label>
              <input type="date" id="date" name="date" required min="<?php echo e(now()->format('Y-m-d')); ?>" max="<?php echo e(now()->addDays(45)->format('Y-m-d')); ?>">
            </div>

            <div>
              <label for="time">Tijd:</label>
              <select id="time" name="time" required>
                <option value="09:00">09:00 – 12:00</option>
                <option value="13:00">13:00 – 16:00</option>
              </select>
            </div>

            <button type="submit" class="btn">Bevestig Reservatie</button>
          </form>
        </div>
        <div class="reservation-form">
          <p>Wil je jouw bestaande reserveringen bekijken?</p>
          <a href="<?php echo e(route('mijn-reservaties')); ?>" class="btn">Bekijk Mijn Reservaties</a>
        </div>
      <?php else: ?>
        <p>Geen lespakket geselecteerd. Selecteer een <a href="<?php echo e(route('pakketten')); ?>">lespakket</a>.</p>
      <?php endif; ?>
    <?php endif; ?>


  </main>

</body>
</html><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/reservations.blade.php ENDPATH**/ ?>