<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Mijn Reservaties | Windkracht-12</title>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
</head>
<body>

    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="container">
        <h1>Mijn Reservaties</h1>

        <?php if($reservations->isEmpty()): ?>
            <p>Je hebt nog geen reservaties gemaakt.</p>
        <?php else: ?>
        <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="pakket">
        <h2><?php echo e($reservation->lessonPackage->name); ?></h2>
        <p><?php echo e($reservation->lessonPackage->description); ?></p>
        <p>Datum: <?php echo e($reservation->date); ?></p>
        <p>Tijd: <?php echo e($reservation->time); ?></p>
        <p>Status: 
    <?php if($reservation->status === 'pending'): ?>
        <span style="color: orange;">In afwachting</span>
    <?php elseif($reservation->status === 'accepted'): ?>
        <span style="color: green;">Goedgekeurd</span>
    <?php elseif($reservation->status === 'rejected'): ?>
        <span style="color: red;">Geweigerd</span>
    <?php endif; ?>
</p>

        
        <form method="POST" action="<?php echo e(route('reservations.cancel', $reservation->id)); ?>" onsubmit="return confirm('Weet je zeker dat je deze reservatie wilt annuleren?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn">Annuleer</button>
        </form>
    </div>         
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </main>

</body>
</html><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/mijn-reservaties.blade.php ENDPATH**/ ?>