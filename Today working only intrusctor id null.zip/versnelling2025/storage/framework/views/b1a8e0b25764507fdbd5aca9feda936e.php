<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Veelgestelde Vragen (FAQ)</title>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
    <style>
        .faq-section {
            max-width: 700px;
            margin: 40px auto;
            padding: 20px;
        }

        .faq-item {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }

        .faq-question {
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 5px;
        }

        .faq-answer {
            display: none;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="faq-section">
    <h1>Veelgestelde Vragen</h1>

    <input type="text" id="faq-search" placeholder="Zoek een vraag..." style="width: 100%; padding: 10px; margin: 20px 0; border: 1px solid #ccc; border-radius: 4px;">

    <div class="faq-item">
        <div class="faq-question">Hoe kan ik een les reserveren?</div>
        <div class="faq-answer">Klik op 'Lespakketten', kies een pakket en volg de reserveringsstappen.</div>
    </div>

    <div class="faq-item">
        <div class="faq-question">Kan ik mijn reservering annuleren?</div>
        <div class="faq-answer">Ja, je kunt je reservering annuleren via het overzicht op de pagina ‘Mijn Reserveringen’.</div>
    </div>

    <div class="faq-item">
        <div class="faq-question">Wat als er geen instructeur beschikbaar is?</div>
        <div class="faq-answer">Je krijgt automatisch een melding als er geen instructeur beschikbaar is voor het gekozen tijdstip.</div>
    </div>
</main>

    <script>
        document.querySelectorAll('.faq-question').forEach(q => {
            q.addEventListener('click', () => {
                const answer = q.nextElementSibling;
                answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
            });
        });
    </script>
    <script>
    document.querySelectorAll('.faq-question').forEach(q => {
        q.addEventListener('click', () => {
            const answer = q.nextElementSibling;
            answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
        });
    });

    const searchInput = document.getElementById('faq-search');
    searchInput.addEventListener('input', function () {
        const filter = this.value.toLowerCase();
        const items = document.querySelectorAll('.faq-item');

        items.forEach(item => {
            const question = item.querySelector('.faq-question').textContent.toLowerCase();
            if (question.includes(filter)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    });
</script>
</body>
</html><?php /**PATH /Users/hernanmartinomolina/Desktop/windkracht12 hernan 2/versnelling2025/resources/views/faq.blade.php ENDPATH**/ ?>